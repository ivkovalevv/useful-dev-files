<?php
/*
Template Name: Шаблон Главной страницы
*/
?>

<?php get_header() ?>

<div class="section section-hero">
        <div class="container section-hero__container">
            <h1 class="section-heading section-hero__heading">
                <?php the_field('main_title'); ?>
            </h1>
            <p class="section-description section-hero__description">
                <?php the_field('main_description'); ?>
            </p>
            <img class="section-hero__image" src="<?php the_field('main_image'); ?>" alt="image"/>
            <button popovertarget="modal" class="buttton section-hero__buttton">купить</button>
            <br/>
            <a href="http://u3294559.isp.regruhosting.ru/test-page/" class="buttton section-hero__buttton" style="display: inline-block;">Тестовая ссылка на другую страницу</a>
        </div>
        <?php if( have_rows('main_partners') ): ?>
            <?php while( have_rows('main_partners') ): the_row(); ?>
               <ul class="section-hero__partners-list">
                    <li class="section-hero__partners-item">
                        <svg class="partners-logo <?php the_sub_field('main_partners-logo-1'); ?>">
                            <use xlink:href="#<?php the_sub_field('main_partners-logo-1'); ?>"></use>
                        </svg>
                    </li>
                    <li class="section-hero__partners-item">
                        <svg class="partners-logo <?php the_sub_field('main_partners-logo-2'); ?>">
                            <use xlink:href="#<?php the_sub_field('main_partners-logo-2'); ?>"></use>
                        </svg>
                    </li>
                    <li class="section-hero__partners-item">
                        <svg class="partners-logo <?php the_sub_field('main_partners-logo-3'); ?>">
                            <use xlink:href="#<?php the_sub_field('main_partners-logo-3'); ?>"></use>
                        </svg>
                    </li>
                    <li class="section-hero__partners-item">
                        <svg class="partners-logo <?php the_sub_field('main_partners-logo-4'); ?>">
                            <use xlink:href="#<?php the_sub_field('main_partners-logo-4'); ?>"></use>
                        </svg>
                    </li>
                    <li class="section-hero__partners-item">
                        <svg class="partners-logo <?php the_sub_field('main_partners-logo-5'); ?>">
                            <use xlink:href="#<?php the_sub_field('main_partners-logo-5'); ?>"></use>
                        </svg>
                    </li>
                    <li class="section-hero__partners-item">
                        <svg class="partners-logo <?php the_sub_field('main_partners-logo-6'); ?>">
                            <use xlink:href="#<?php the_sub_field('main_partners-logo-6'); ?>"></use>
                        </svg>
                    </li>
                    <li class="section-hero__partners-item">
                        <svg class="partners-logo <?php the_sub_field('main_partners-logo-7'); ?>">
                            <use xlink:href="#<?php the_sub_field('main_partners-logo-7'); ?>"></use>
                        </svg>
                    </li>
                    <li class="section-hero__partners-item">
                        <svg class="partners-logo <?php the_sub_field('main_partners-logo-8'); ?>">
                            <use xlink:href="#<?php the_sub_field('main_partners-logo-8'); ?>"></use>
                        </svg>
                    </li>
                    <li class="section-hero__partners-item">
                        <svg class="partners-logo <?php the_sub_field('main_partners-logo-1'); ?>">
                            <use xlink:href="#<?php the_sub_field('main_partners-logo-1'); ?>"></use>
                        </svg>
                    </li>
                    <li class="section-hero__partners-item">
                        <svg class="partners-logo <?php the_sub_field('main_partners-logo-2'); ?>">
                            <use xlink:href="#<?php the_sub_field('main_partners-logo-2'); ?>"></use>
                        </svg>
                    </li>
                    <li class="section-hero__partners-item">
                        <svg class="partners-logo <?php the_sub_field('main_partners-logo-3'); ?>">
                            <use xlink:href="#<?php the_sub_field('main_partners-logo-3'); ?>"></use>
                        </svg>
                    </li>
                    <li class="section-hero__partners-item">
                        <svg class="partners-logo <?php the_sub_field('main_partners-logo-4'); ?>">
                            <use xlink:href="#<?php the_sub_field('main_partners-logo-4'); ?>"></use>
                        </svg>
                    </li>
                    <li class="section-hero__partners-item">
                        <svg class="partners-logo <?php the_sub_field('main_partners-logo-5'); ?>">
                            <use xlink:href="#<?php the_sub_field('main_partners-logo-5'); ?>"></use>
                        </svg>
                    </li>
                    <li class="section-hero__partners-item">
                        <svg class="partners-logo <?php the_sub_field('main_partners-logo-6'); ?>">
                            <use xlink:href="#<?php the_sub_field('main_partners-logo-6'); ?>"></use>
                        </svg>
                    </li>
                    <li class="section-hero__partners-item">
                        <svg class="partners-logo <?php the_sub_field('main_partners-logo-7'); ?>">
                            <use xlink:href="#<?php the_sub_field('main_partners-logo-7'); ?>"></use>
                        </svg>
                    </li>
                    <li class="section-hero__partners-item">
                        <svg class="partners-logo <?php the_sub_field('main_partners-logo-8'); ?>">
                            <use xlink:href="#<?php the_sub_field('main_partners-logo-8'); ?>"></use>
                        </svg>
                    </li>
                </ul>
            <?php endwhile; ?>
        <?php endif; ?>
    </div>

    <div id="about" class="section section-nearby">
        <div class="container section-nearby__container">
            <h2 class="section-heading section-nearby__heading nearby__heading-one">
                <?php the_field('nearby__heading-1'); ?>
            </h2>
            <ul class="section-nearby__description-list">
                <li class="section-nearby__description-item">
                    <p class="section-description section-nearby__item-description">
                        <?php the_field('nearby__description-1'); ?>
                    </p>
                </li>
                <li class="section-nearby__description-item">
                    <p class="section-description section-nearby__item-description">
                        <?php the_field('nearby__description-2'); ?>
                    </p>
                </li>
            </ul>

            <h2 class="section-heading section-nearby__heading nearby__heading-two">
                <?php the_field('nearby__heading-2'); ?>
            </h2>
            <?php
                $args = array(
                  'post_type' => 'post',
                  'post_status' => 'publish',
                  'posts_per_page' => 6, // Количество записей
                );
                 
                $query = new WP_Query($args);
                 
                if ($query->have_posts()) : $i = 0;
                ?>
                 
                <ul class="section-nearby__list">
                  <?php while ($query->have_posts()) : $i++; $query->the_post(); ?>
                    <li class="section-nearby__item section-nearby__item<?php echo $i; ?>">
                    <style>
                        .section-nearby__item<?php echo $i; ?>{
                            background-image: url('<?php the_field('background_img'); ?>');
                            background-repeat: no-repeat;
                            background-position: center center;
                        }
                    </style>
                        <a href="<?php the_permalink(); ?>"></a>
                        <h4 class="section-nearby__item-heading">
                            •  <?php the_title(); ?>
                        </h4>
                        <p class="section-nearby__item-description">
                            <?php the_field('services_description'); ?>
                        </p>
                    </li>
                  <?php endwhile; wp_reset_postdata(); ?>
                </ul>
                 
            <?php endif; ?>
        </div>
    </div>

    <div id="services" class="section section-services">
        <div class="container section-services__container">
            <h2 class="section-heading section-services__heading services__heading-one">
                Наши услуги
            </h2>
            <ul class="section-services__list">
                <li class="section-services__item">
                    <h4 class="section-services__item-heading">
                        Помощь при выборе товара и продавца
                    </h4>
                    <p class="section-description section-services__item-description">
                        поможем выбрать лучший вариант для Вас
                    </p>
                    <button popovertarget="modal" class="section-services__item-button">
                        <svg class="link-arrow">
                            <use xlink:href="#link-arrow"></use>
                        </svg>
                        <svg class="link-arrow-mob">
                            <use xlink:href="#link-arrow-mob"></use>
                        </svg>
                    </button>
                </li>
                <li class="section-services__item">
                    <h4 class="section-services__item-heading">
                        Конвертация валюты
                    </h4>
                    <p class="section-description section-services__item-description">
                        посредники при этом не используются
                    </p>
                    <button popovertarget="modal" class="section-services__item-button">
                        <svg class="link-arrow">
                            <use xlink:href="#link-arrow"></use>
                        </svg>
                        <svg class="link-arrow-mob">
                            <use xlink:href="#link-arrow-mob"></use>
                        </svg>
                    </button>
                </li>
                <li class="section-services__item">
                    <h4 class="section-services__item-heading">
                        Выкуп
                    </h4>
                    <p class="section-description section-services__item-description">
                        выкупаем и предоставляем инвойсы
                    </p>
                    <button popovertarget="modal" class="section-services__item-button">
                        <svg class="link-arrow">
                            <use xlink:href="#link-arrow"></use>
                        </svg>
                        <svg class="link-arrow-mob">
                            <use xlink:href="#link-arrow-mob"></use>
                        </svg>
                    </button>
                </li>
                <li class="section-services__item">
                    <h4 class="section-services__item-heading">
                        Доставка по РФ
                    </h4>
                    <p class="section-description section-services__item-description">
                        оформляем заказ сразу до Вашего адреса
                    </p>
                    <button popovertarget="modal" class="section-services__item-button">
                        <svg class="link-arrow">
                            <use xlink:href="#link-arrow"></use>
                        </svg>
                        <svg class="link-arrow-mob">
                            <use xlink:href="#link-arrow-mob"></use>
                        </svg>
                    </button>
                </li>
            </ul>
            <h2 class="section-heading section-services__heading services__heading-two">
                Два варианта оформления заказа
            </h2>
            <ul class="section-services__elems">
                <li class="section-services__elem">
                    <h4 class="section-services__elem-heading">
                        Полная предоплата
                    </h4>
                    <p class="section-nearby__item-description">
                        Покупка происходит по полной предоплате стоимости товара и доставки, платеж может быть разделен в случае наличия пошлины: пошлина и стоимость доставки до РФ в случае ,если тоовар санкционный, не входит в сумму расходов и может быть оплачена позже. <br/>
                        Стоимость комисси при этом составляет 20% от стоимости товара. <br/>
                        Подробные условия указаны в <a href="<?php echo get_template_directory_uri(); ?>/pdfs/prepayment100.pdf" download class="nearby__item-link">договоре.</a> 
                    </p>
                </li>
                <li class="section-services__elem">
                    <h4 class="section-services__elem-heading">
                        Частичная предоплата
                    </h4>
                    <p class="section-nearby__item-description">
                        Покупка происходит по частичной (15% от стоимости товара и его доставки либо до РФ, либо до транзитного пункта в стране таможенного союза, в случае, если товар санкционный). <br/>
                        Оставшаяся сумма вносится по прибытии товара в РФ, или страну таможенного союза, комиссия при этом составляет 100% от стоимости товара и его доставки. <br/>
                        Подробные условия указаны в <a href="<?php echo get_template_directory_uri(); ?>/pdfs/prepayment15.pdf" download class="nearby__item-link">договоре.</a>
                    </p>
                </li>
                </ul>
        </div>
    </div>

    <div id="contacts" class="section section-contacts">
        <div class="container section-contacts__container">
            <h2 class="section-heading section-contacts__heading">
                Свяжитесь с нами по любому вопросу
            </h2>
            <ul class="section-contacts__links">
                <li class="section-contacts__link-wrapper">
                    <a href="https://t.me/Goods_delivery_service" target="_blank" class="section-contacts__link">
                        <p class="section-contacts__link-title">перейти в telegram</p>
                        <svg class="tg">
                            <use xlink:href="#tg"></use>
                        </svg>
                    </a>
                </li>
                <li class="section-contacts__link-wrapper">
                    <a href="https://wa.me/qr/6ENIESZ4OW4IA1" target="_blank" class="section-contacts__link">
                        <p class="section-contacts__link-title">перейти в whats up</p>
                        <svg class="wa">
                            <use xlink:href="#wa"></use>
                        </svg>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    

<?php get_footer() ?>