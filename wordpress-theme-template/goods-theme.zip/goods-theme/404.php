<?php get_header() ?>

<h1>Это страница 404, ты заплутал, друг.</h1>

<?php get_footer() ?>