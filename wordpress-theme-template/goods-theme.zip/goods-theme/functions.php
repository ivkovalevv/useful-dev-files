<?php

define( 'GOODS_THEME_ROOT' , get_template_directory_uri() );
define( 'GOODS_IMG_DIR' , GOODS_THEME_ROOT . '/images' );

add_action( 'wp_enqueue_scripts', 'theme_name_scripts' );

function theme_name_scripts() {
    wp_enqueue_style( 'main-css', get_template_directory_uri() . '/css/main.css' );
    wp_enqueue_script( 'app-js', get_template_directory_uri() . '/js/app.js', array(), '1.0.0', true );
}

if (function_exists("acf_add_options_page")) {
    acf_add_options_page(array(
        "page_title" => "Настройки сайта",
        "menu_title" => "Настройки сайта",
        "menu_slug"  => "theme_settings",
    ));
}