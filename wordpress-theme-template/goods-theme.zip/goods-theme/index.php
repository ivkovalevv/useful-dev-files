<?php get_header() ?>

<div class="section section-hero">
        <div class="container section-hero__container">
            <h1 class="section-heading section-hero__heading">
                Сервис доставки</br> товаров из-за</br> рубежа
            </h1>
            <p class="section-description section-hero__description">
                Любимые бренды. Товары с Ebay, Amazon, интернет-магазинов и маркетплейсов США, Европы, Китая и ОАЭ.
            </p>
            <img class="section-hero__image" src="<?php echo GOODS_IMG_DIR ?>/worker.png" alt="image"/>
            <button popovertarget="modal" class="buttton section-hero__buttton">купить</button>
            <br/>
            <a href="http://u3294559.isp.regruhosting.ru/test-page/" class="buttton section-hero__buttton" style="display: inline-block;">Тестовая ссылка на другую страницу</a>
        </div>
        <ul class="section-hero__partners-list">
            <li class="section-hero__partners-item">
                <svg class="partners-logo nike">
                <use xlink:href="#nike"></use>
            </svg>
            </li>
            <li class="section-hero__partners-item">
                <svg class="partners-logo amazon">
                <use xlink:href="#amazon"></use>
            </svg>
            </li>
            <li class="section-hero__partners-item">
                <svg class="partners-logo ebay">
                <use xlink:href="#ebay"></use>
            </svg>
            </li>
            <li class="section-hero__partners-item">
                <svg class="partners-logo s">
                <use xlink:href="#s"></use>
            </svg>
            </li>
            <li class="section-hero__partners-item">
                <svg class="partners-logo tnf">
                <use xlink:href="#tnf"></use>
            </svg>
            </li>
            <li class="section-hero__partners-item">
                <svg class="partners-logo adidas">
                <use xlink:href="#adidas"></use>
            </svg>
            </li>
            <li class="section-hero__partners-item">
                <svg class="partners-logo bb">
                <use xlink:href="#bb"></use>
            </svg>
            </li>
            <li class="section-hero__partners-item">
                <svg class="partners-logo asos">
                <use xlink:href="#asos"></use>
            </svg>
            </li>
            <li class="section-hero__partners-item">
                <svg class="partners-logo nike">
                <use xlink:href="#nike"></use>
            </svg>
            </li>
            <li class="section-hero__partners-item">
                <svg class="partners-logo amazon">
                <use xlink:href="#amazon"></use>
            </svg>
            </li>
            <li class="section-hero__partners-item">
                <svg class="partners-logo ebay">
                <use xlink:href="#ebay"></use>
            </svg>
            </li>
            <li class="section-hero__partners-item">
                <svg class="partners-logo s">
                <use xlink:href="#s"></use>
            </svg>
            </li>
            <li class="section-hero__partners-item">
                <svg class="partners-logo tnf">
                <use xlink:href="#tnf"></use>
            </svg>
            </li>
            <li class="section-hero__partners-item">
                <svg class="partners-logo adidas">
                <use xlink:href="#adidas"></use>
            </svg>
            </li>
            <li class="section-hero__partners-item">
                <svg class="partners-logo bb">
                <use xlink:href="#bb"></use>
            </svg>
            </li>
            <li class="section-hero__partners-item">
                <svg class="partners-logo asos">
                <use xlink:href="#asos"></use>
            </svg>
            </li>
        </ul>
    </div>

    <div id="about" class="section section-nearby">
        <div class="container section-nearby__container">
            <h2 class="section-heading section-nearby__heading nearby__heading-one">
                GOOD`S DELIVERY - Всегда рядом
            </h2>
            <ul class="section-nearby__description-list">
                <li class="section-nearby__description-item">
                    <p class="section-description section-nearby__item-description">
                        Мы осуществляем полный цикл доставки, в том числе санкционных товаров, – от выкупа до вручения посылки на конечном адресе, всё время сделки оставаясь на связи.
                    </p>
                </li>
                <li class="section-nearby__description-item">
                    <p class="section-description section-nearby__item-description">
                        Выкупаем как по ссылкам, так и осуществляем поиск по запросу.
                    </p>
                </li>
            </ul>

            <h2 class="section-heading section-nearby__heading nearby__heading-two">
                С нами легко и быстро
            </h2>
            <ul class="section-nearby__list">
                <li class="section-nearby__item">
                    <h4 class="section-nearby__item-heading">
                        •  Помощь в выборе
                    </h4>
                    <p class="section-nearby__item-description">
                        Мы производим необходимые консультации, ищем товар, если необходимо. Изучаем рынок, подбираем наиболее выгодное предложение и оптимальный маршрут доставки.
                    </p>
                </li>
                <li class="section-nearby__item">
                    <h4 class="section-nearby__item-heading">
                        •  Оформление
                    </h4>
                    <p class="section-nearby__item-description">
                        Связываетесь с нами в мессенджерах или по телефону, формулируете запрос, или предоставляете сслылку уже выбранного товара.
                    </p>
                </li>
                <li class="section-nearby__item">
                    <h4 class="section-nearby__item-heading">
                        •  Оплата
                    </h4>
                    <p class="section-nearby__item-description">
                        Выбираем один из двух возможных вариантов оплаты – возможна покупка по частичной предоплате! Считаем стоимость товара под ключ, расписываем стоимость каждого этапа. Вы принимаете решение.
                    </p>
                </li>
                <li class="section-nearby__item">
                    <h4 class="section-nearby__item-heading">
                        •  Прозрачная сделка
                    </h4>
                    <p class="section-nearby__item-description">
                        Сотрудничество происходит по договору. Выкупаем, предоставляем инвойсы и трек-номера, находимся с Вами на связи, информируем о движении посылки.
                    </p>
                </li>
            </ul>
        </div>
    </div>

    <div id="services" class="section section-services">
        <div class="container section-services__container">
            <h2 class="section-heading section-services__heading services__heading-one">
                Наши услуги
            </h2>
            <ul class="section-services__list">
                <li class="section-services__item">
                    <h4 class="section-services__item-heading">
                        Помощь при выборе товара и продавца
                    </h4>
                    <p class="section-description section-services__item-description">
                        поможем выбрать лучший вариант для Вас
                    </p>
                    <button popovertarget="modal" class="section-services__item-button">
                        <svg class="link-arrow">
                            <use xlink:href="#link-arrow"></use>
                        </svg>
                        <svg class="link-arrow-mob">
                            <use xlink:href="#link-arrow-mob"></use>
                        </svg>
                    </button>
                </li>
                <li class="section-services__item">
                    <h4 class="section-services__item-heading">
                        Конвертация валюты
                    </h4>
                    <p class="section-description section-services__item-description">
                        посредники при этом не используются
                    </p>
                    <button popovertarget="modal" class="section-services__item-button">
                        <svg class="link-arrow">
                            <use xlink:href="#link-arrow"></use>
                        </svg>
                        <svg class="link-arrow-mob">
                            <use xlink:href="#link-arrow-mob"></use>
                        </svg>
                    </button>
                </li>
                <li class="section-services__item">
                    <h4 class="section-services__item-heading">
                        Выкуп
                    </h4>
                    <p class="section-description section-services__item-description">
                        выкупаем и предоставляем инвойсы
                    </p>
                    <button popovertarget="modal" class="section-services__item-button">
                        <svg class="link-arrow">
                            <use xlink:href="#link-arrow"></use>
                        </svg>
                        <svg class="link-arrow-mob">
                            <use xlink:href="#link-arrow-mob"></use>
                        </svg>
                    </button>
                </li>
                <li class="section-services__item">
                    <h4 class="section-services__item-heading">
                        Доставка по РФ
                    </h4>
                    <p class="section-description section-services__item-description">
                        оформляем заказ сразу до Вашего адреса
                    </p>
                    <button popovertarget="modal" class="section-services__item-button">
                        <svg class="link-arrow">
                            <use xlink:href="#link-arrow"></use>
                        </svg>
                        <svg class="link-arrow-mob">
                            <use xlink:href="#link-arrow-mob"></use>
                        </svg>
                    </button>
                </li>
            </ul>
            <h2 class="section-heading section-services__heading services__heading-two">
                Два варианта оформления заказа
            </h2>
            <ul class="section-services__elems">
                <li class="section-services__elem">
                    <h4 class="section-services__elem-heading">
                        Полная предоплата
                    </h4>
                    <p class="section-nearby__item-description">
                        Покупка происходит по полной предоплате стоимости товара и доставки, платеж может быть разделен в случае наличия пошлины: пошлина и стоимость доставки до РФ в случае ,если тоовар санкционный, не входит в сумму расходов и может быть оплачена позже. <br/>
                        Стоимость комисси при этом составляет 20% от стоимости товара. <br/>
                        Подробные условия указаны в <a href="<?php echo get_template_directory_uri(); ?>/pdfs/prepayment100.pdf" download class="nearby__item-link">договоре.</a> 
                    </p>
                </li>
                <li class="section-services__elem">
                    <h4 class="section-services__elem-heading">
                        Частичная предоплата
                    </h4>
                    <p class="section-nearby__item-description">
                        Покупка происходит по частичной (15% от стоимости товара и его доставки либо до РФ, либо до транзитного пункта в стране таможенного союза, в случае, если товар санкционный). <br/>
                        Оставшаяся сумма вносится по прибытии товара в РФ, или страну таможенного союза, комиссия при этом составляет 100% от стоимости товара и его доставки. <br/>
                        Подробные условия указаны в <a href="<?php echo get_template_directory_uri(); ?>/pdfs/prepayment15.pdf" download class="nearby__item-link">договоре.</a>
                    </p>
                </li>
                </ul>
        </div>
    </div>

    <div id="contacts" class="section section-contacts">
        <div class="container section-contacts__container">
            <h2 class="section-heading section-contacts__heading">
                Свяжитесь с нами по любому вопросу
            </h2>
            <ul class="section-contacts__links">
                <li class="section-contacts__link-wrapper">
                    <a href="https://t.me/Goods_delivery_service" target="_blank" class="section-contacts__link">
                        <p class="section-contacts__link-title">перейти в telegram</p>
                        <svg class="tg">
                            <use xlink:href="#tg"></use>
                        </svg>
                    </a>
                </li>
                <li class="section-contacts__link-wrapper">
                    <a href="https://wa.me/qr/6ENIESZ4OW4IA1" target="_blank" class="section-contacts__link">
                        <p class="section-contacts__link-title">перейти в whats up</p>
                        <svg class="wa">
                            <use xlink:href="#wa"></use>
                        </svg>
                    </a>
                </li>
            </ul>
        </div>
    </div>

<?php get_footer() ?>