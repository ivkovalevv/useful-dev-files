<footer class="footer">
        <div class="container footer__container">
            <div class="footer__information">
                <h4 class="footer__information-heading">Информация</h4>
                <ul class="footer__information-list">
                    <li class="footer__information-item">
                        ИП Хохлов Данила Андреевич
                    </li>
                    <li class="footer__information-item">
                        ИНН: 631402167720
                    </li>
                    <li class="footer__information-item">
                        ОГРНИП: 325632700132851
                    </li>
                    <li class="footer__information-item">
                        Р/С: 3010 1810 2000 0000 0824
                    </li>
                </ul>
            </div>
            <div class="footer__content-wrapper">
                <ul class="footer__navigation">
                    <li class="footer__navigation-item">
                        <a href="#about" class="footer__navigation-link">О нас</a>
                    </li>
                    <li class="footer__navigation-item">
                        <a href="#contacts" class="footer__navigation-link">Контакты</a>
                    </li>
                    <li class="footer__navigation-item">
                        <a href="#services" class="footer__navigation-link">Наши услуги</a>
                    </li>
                </ul>
                <h2 class="footer__signature">
                    Good`s DELIVERY
                </h2>
            </div>
        </div>
    </footer>
    <?php wp_footer(); ?>
    <script src="<?php echo get_template_directory_uri(); ?>/js/app.js"></script>
</body>
</html>