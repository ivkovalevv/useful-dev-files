<?php
/*
    Template name: Page "Contacts" 
*/
?>

<?php get_header() ?>

<h1>Страница контактов</h1>
<div class="container">
    <div id="map" style="border-radius: 20px; overflow: auto;"></div>
</div>
<script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3Acf9c55f1a8be6fde5ca9c683f3683ff9c3e04069dbe08050c010661d25e2233b&amp;width=100%25&amp;height=720&amp;id=map&amp;lang=ru_RU&amp;scroll=true"></script>
<?php get_footer() ?>